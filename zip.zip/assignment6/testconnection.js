const { Sequelize } = require('sequelize');

const sequelize = new Sequelize({
    host: 'ep-yellow-resonance-a53k0pyj.us-east-2.aws.neon.tech',
    dialect: 'postgres',
    database: 'SenecaDB',
    username: 'SenecaDB_owner',
    password: 'e2I6hRTCxXHJ',
    logging: false,
    dialectOptions: {
        ssl: {
            require: true,
            rejectUnauthorized: false
        }
    }
});

sequelize.authenticate()
    .then(() => {
        console.log('Connection has been established successfully.');
    })
    .catch(err => {
        console.error('Unable to connect to the database:', err);
    });
