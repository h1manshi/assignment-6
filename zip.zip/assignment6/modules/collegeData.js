const { Student, Course, sequelize } = require('./models'); // Adjust path as necessary

function initialize() {
    return new Promise((resolve, reject) => {
        // Synchronize models with the database
        sequelize.sync()
            .then(() => resolve())
            .catch(() => reject("Unable to sync the database"));
    });
}

function getAllStudents() {
    return new Promise((resolve, reject) => {
        Student.findAll()
            .then((data) => resolve(data))
            .catch(() => reject("No results returned"));
    });
}

function getStudentsByCourse(course) {
    return new Promise((resolve, reject) => {
        Student.findAll({ where: { course } })
            .then((data) => resolve(data))
            .catch(() => reject("No results returned"));
    });
}

function getStudentByNum(num) {
    return new Promise((resolve, reject) => {
        Student.findAll({ where: { studentNum: num } })
            .then((data) => resolve(data[0]))
            .catch(() => reject("No results returned"));
    });
}

function getCourses() {
    return new Promise((resolve, reject) => {
        Course.findAll()
            .then((data) => resolve(data))
            .catch(() => reject("No results returned"));
    });
}

function getCourseById(id) {
    return new Promise((resolve, reject) => {
        Course.findAll({ where: { courseId: id } })
            .then((data) => resolve(data[0]))
            .catch(() => reject("No results returned"));
    });
}

function addStudent(studentData) {
    return new Promise((resolve, reject) => {
        // Ensure any blank values are replaced with null
        for (let key in studentData) {
            if (studentData[key] === "") {
                studentData[key] = null;
            }
        }

        // Ensure TA value is set correctly
        studentData.TA = (studentData.TA) ? true : false;

        // Create a new student entry
        Student.create(studentData)
            .then(() => resolve())
            .catch(() => reject("Unable to create student"));
    });
}

function updateStudent(studentData) {
    return new Promise((resolve, reject) => {
        // Ensure any blank values are replaced with null
        for (let key in studentData) {
            if (studentData[key] === "") {
                studentData[key] = null;
            }
        }

        // Ensure TA value is set correctly
        studentData.TA = (studentData.TA) ? true : false;

        // Update the student entry by studentNum
        Student.update(studentData, {
            where: {
                studentNum: studentData.studentNum
            }
        })
            .then(() => resolve())
            .catch(() => reject("Unable to update student"));
    });
}

function addCourse(courseData) {
    return new Promise((resolve, reject) => {
        // Ensure any blank values are replaced with null
        for (let key in courseData) {
            if (courseData[key] === "") {
                courseData[key] = null;
            }
        }

        // Create a new course entry
        Course.create(courseData)
            .then(() => resolve())
            .catch(() => reject("Unable to create course"));
    });
}

function updateCourse(courseData) {
    return new Promise((resolve, reject) => {
        // Ensure any blank values are replaced with null
        for (let key in courseData) {
            if (courseData[key] === "") {
                courseData[key] = null;
            }
        }

        // Update the course entry by courseId
        Course.update(courseData, {
            where: {
                courseId: courseData.courseId
            }
        })
            .then(() => resolve())
            .catch(() => reject("Unable to update course"));
    });
}

function deleteCourseById(id) {
    return new Promise((resolve, reject) => {
        // Delete the course entry by courseId
        Course.destroy({
            where: {
                courseId: id
            }
        })
            .then((rowsDeleted) => {
                if (rowsDeleted > 0) {
                    resolve();
                } else {
                    reject("No course found with the specified id");
                }
            })
            .catch(() => reject("Unable to delete course"));
    });
}

function deleteStudentByNum(studentNum) {
    return new Promise((resolve, reject) => {
        // Delete the student entry by studentNum
        Student.destroy({
            where: {
                studentNum: studentNum
            }
        })
            .then((rowsDeleted) => {
                if (rowsDeleted > 0) {
                    resolve();
                } else {
                    reject("No student found with the specified number");
                }
            })
            .catch(() => reject("Unable to delete student"));
    });
}

module.exports = {
    initialize,
    getAllStudents,
    getStudentsByCourse,
    getStudentByNum,
    getCourses,
    getCourseById,
    addStudent,
    updateStudent,
    addCourse,
    updateCourse,
    deleteCourseById,
    deleteStudentByNum
};
